  <!-- Scripts -->
  <script src="<?= ASSETS ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= ASSETS ?>/js/main.js"></script>
</body>
</html>
