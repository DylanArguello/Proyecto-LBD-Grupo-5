<?php
// Ruta base: lo que escribes después de localhost
define('BASE_URL', '/Proyecto-LBD-Grupo-5');

// Directorio de vistas
define('VIEW_PATH', __DIR__ . '/View');

// Assets helper
define('ASSETS', BASE_URL . '/View/assets');
